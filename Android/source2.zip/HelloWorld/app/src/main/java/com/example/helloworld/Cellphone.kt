package com.example.helloworld

data class Cellphone(val brand: String, val price: Double)